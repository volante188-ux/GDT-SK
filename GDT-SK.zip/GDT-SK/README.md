# GDT SK — Gravador de tela para Android

Gravador de tela simples e leve. Kotlin, sem bibliotecas externas (só a plataforma Android).

- Grava a tela em **MP4 (H.264 + AAC)** e salva direto na galeria (**Filmes/GDT SK**)
- Iniciar, **pausar, continuar** e parar
- Resolução 480p / 720p / 1080p / 1440p / personalizada, FPS 15–120, taxa de bits (ou automática)
- Áudio: sem áudio, **interno** (Android 10+) ou **microfone**
- Controles pela **notificação** e, opcionalmente, por uma **bolha flutuante**

## Como compilar

### Opção A — Android Studio
1. Instale o Android Studio (versão recente) e abra a pasta `GDT-SK`.
2. Aguarde o *Gradle Sync* (ele baixa o SDK 35 se faltar; aceite as licenças).
3. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. O APK fica em `app/build/outputs/apk/release/app-release.apk`
   (ou rode direto no celular com o botão ▶ usando depuração USB).

### Opção B — Linha de comando
Com JDK 17 e o Android SDK instalados (`ANDROID_HOME` definido):

```
./gradlew assembleRelease
```

O APK sai em `app/build/outputs/apk/release/app-release.apk`. Ele é assinado com a chave de debug, então instala direto.

### Opção C — Sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e envie esta pasta.
2. Aba **Actions → Build APK → Run workflow**.
3. Baixe o APK em *Artifacts* (`GDT-SK-apk`).

## Instalar no celular
Copie o APK para o celular, abra e permita "instalar apps desconhecidos" para o app que você usou para abri-lo.

## Como funciona
| Parte | Arquivo |
|---|---|
| Tela principal (qualidade, FPS, áudio) | `MainActivity.kt` |
| Serviço em primeiro plano + notificação | `RecorderService.kt` |
| Captura → codificação → MP4 | `ScreenRecorder.kt` |
| Bolha flutuante | `FloatingBubble.kt` |
| Limites do aparelho (encoder, tela) | `DeviceLimits.kt` |
| Arquivo na galeria (MediaStore) | `Storage.kt` |
| Lista de gravações | `RecordingsActivity.kt` |

Permissões: captura de tela (diálogo do sistema a cada gravação), notificações (Android 13+), microfone (só se escolher áudio), sobreposição (só se ligar a bolha).

## Limitações do Android (importante)
- **Bolha no vídeo:** o Android não permite excluir uma janela de sobreposição da captura. Em vários aparelhos a bolha **aparece no vídeo**. Se acontecer, desligue a bolha e controle pela **notificação** (ela não fica sobre a tela). Os ícones da barra de status continuam aparecendo, como em qualquer gravador.
- **Áudio interno:** só Android 10+, e apps podem bloquear a captura (chamadas, alguns apps de streaming/DRM). Nesses casos o áudio sai mudo.
- **FPS:** 90/120 só aparecem em telas que chegam a essa taxa, e só valem se o conteúdo atualizar nessa taxa. A lista também respeita o limite do codificador do aparelho.
- **Conteúdo protegido (DRM/janelas seguras)** aparece preto, por regra do sistema.
- **Rotação:** a resolução é fixada na orientação do momento em que a gravação começa.
- **Se o app for morto à força** (ex.: bateria acabou) durante a gravação, aquele MP4 pode ficar incompleto. As gravações anteriores nunca são afetadas: cada uma é um arquivo separado.
