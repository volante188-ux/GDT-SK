package com.gdtsk.recorder

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Switch
import android.widget.Toast
import kotlin.math.min

class MainActivity : Activity() {

    companion object {
        private const val REQ_PERMS = 1
        private const val REQ_PROJECTION = 2
        private val PRESETS = listOf(480, 720, 1080, 1440)
        private val FPS_ALL = listOf(15, 24, 30, 60, 90, 120)
    }

    private lateinit var spRes: Spinner
    private lateinit var spFps: Spinner
    private lateinit var spAudio: Spinner
    private lateinit var etCustom: EditText
    private lateinit var etBitrate: EditText
    private lateinit var swBubble: Switch

    private var presets: List<Int> = emptyList()
    private var fpsOptions: List<Int> = emptyList()
    private var audioOptions: List<Int> = emptyList()
    private var pending: RecConfig? = null

    private val prefs by lazy { getSharedPreferences("gdtsk", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Insets.apply(findViewById(R.id.root))

        spRes = findViewById(R.id.spRes)
        spFps = findViewById(R.id.spFps)
        spAudio = findViewById(R.id.spAudio)
        etCustom = findViewById(R.id.etCustom)
        etBitrate = findViewById(R.id.etBitrate)
        swBubble = findViewById(R.id.swBubble)

        val (sw, sh) = DeviceLimits.screenSize(this)
        val nativeShort = min(sw, sh)

        // Só oferece o que o aparelho suporta.
        presets = PRESETS.filter { p ->
            p <= nativeShort + 8 && DeviceLimits.sizeFor(p, sw, sh).let { (w, h) -> DeviceLimits.supportsSize(w, h) }
        }
        val refresh = DeviceLimits.maxRefreshHz(this)
        fpsOptions = FPS_ALL.filter { it <= 30 || it <= refresh + 1 }
        audioOptions = if (Build.VERSION.SDK_INT >= 29) listOf(Audio.NONE, Audio.INTERNAL, Audio.MIC)
        else listOf(Audio.NONE, Audio.MIC)

        setAdapter(spRes, presets.map { "${it}p" } + "Personalizada")
        setAdapter(spFps, fpsOptions.map { "$it FPS" })
        setAdapter(spAudio, audioOptions.map {
            when (it) {
                Audio.INTERNAL -> "Áudio interno do celular"
                Audio.MIC -> "Microfone"
                else -> "Sem áudio"
            }
        })

        spRes.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                etCustom.visibility = if (pos == presets.size) View.VISIBLE else View.GONE
            }

            override fun onNothingSelected(p: AdapterView<*>?) {}
        }

        // Restaura a última escolha.
        spRes.setSelection(prefs.getInt("res", presets.indexOf(720).coerceAtLeast(0)).coerceIn(0, presets.size))
        spFps.setSelection(prefs.getInt("fps", fpsOptions.indexOf(30).coerceAtLeast(0)).coerceIn(0, fpsOptions.size - 1))
        spAudio.setSelection(prefs.getInt("audio", 0).coerceIn(0, audioOptions.size - 1))
        etCustom.setText(prefs.getString("custom", ""))
        etBitrate.setText(prefs.getString("bitrate", ""))
        swBubble.isChecked = prefs.getBoolean("bubble", false)

        findViewById<Button>(R.id.btnStart).setOnClickListener { onStartClicked() }
        findViewById<Button>(R.id.btnList).setOnClickListener {
            startActivity(Intent(this, RecordingsActivity::class.java))
        }
    }

    private fun setAdapter(sp: Spinner, items: List<String>) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).also {
            it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    // ------------------------------------------------------------------ fluxo de início

    private fun onStartClicked() {
        if (RecorderService.active) {
            toast("Já existe uma gravação em andamento.")
            return
        }
        pending = buildConfig() ?: return
        ensurePermissions()
    }

    private fun buildConfig(): RecConfig? {
        val (sw, sh) = DeviceLimits.screenSize(this)
        val nativeShort = min(sw, sh)

        val resPos = spRes.selectedItemPosition
        val shortSide = if (resPos in presets.indices) {
            presets[resPos]
        } else {
            val v = etCustom.text.toString().trim().toIntOrNull()
            if (v == null || v < 144) {
                toast("Informe o lado menor da resolução em pixels (mínimo 144).")
                return null
            }
            min(v, nativeShort)
        }

        val (w, h) = DeviceLimits.sizeFor(shortSide, sw, sh)
        if (!DeviceLimits.supportsSize(w, h)) {
            toast("Este aparelho não suporta ${w}x$h.")
            return null
        }

        val fps = fpsOptions[spFps.selectedItemPosition]
        val maxFps = DeviceLimits.maxFps(w, h)
        if (fps > maxFps) {
            toast("Este aparelho suporta no máximo $maxFps FPS em ${w}x$h.")
            return null
        }

        val range = DeviceLimits.bitrateRange()
        val typed = etBitrate.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val rawBitrate = if (typed != null && typed > 0) typed * 1_000_000.0
        else w.toDouble() * h * fps * 0.07 // automática: ~0,07 bit por pixel por quadro
        val bitrate = rawBitrate.toLong().coerceIn(range.lower.toLong(), range.upper.toLong()).toInt()

        val audio = audioOptions[spAudio.selectedItemPosition]
        val bubble = swBubble.isChecked

        prefs.edit()
            .putInt("res", resPos)
            .putInt("fps", spFps.selectedItemPosition)
            .putInt("audio", spAudio.selectedItemPosition)
            .putString("custom", etCustom.text.toString())
            .putString("bitrate", etBitrate.text.toString())
            .putBoolean("bubble", bubble)
            .apply()

        return RecConfig(w, h, fps, bitrate, audio, bubble, resources.displayMetrics.densityDpi)
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun ensurePermissions() {
        val cfg = pending ?: return
        val need = ArrayList<String>()
        if (cfg.audio != Audio.NONE && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), REQ_PERMS) else askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERMS) return
        var cfg = pending ?: return
        if (Build.VERSION.SDK_INT <= 28 && !has(Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            toast("A permissão de armazenamento é necessária para salvar os vídeos.")
            pending = null
            return
        }
        if (cfg.audio != Audio.NONE && !has(Manifest.permission.RECORD_AUDIO)) {
            cfg = cfg.copy(audio = Audio.NONE)
            pending = cfg
            toast("Sem permissão de áudio: gravando sem som.")
        }
        // Notificações negadas não impedem de gravar (a bolha continua funcionando).
        askProjection()
    }

    private fun askProjection() {
        val cfg = pending ?: return
        if (cfg.bubble && !Settings.canDrawOverlays(this)) {
            toast("Permita \"Sobrepor a outros apps\" e toque em Iniciar de novo.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            pending = null
            return
        }
        val mpm = getSystemService(MediaProjectionManager::class.java)
        @Suppress("DEPRECATION")
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJECTION) return
        val cfg = pending
        pending = null
        if (resultCode != RESULT_OK || data == null || cfg == null) {
            toast("Captura de tela não autorizada.")
            return
        }
        val i = Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_START)
        cfg.putTo(i)
        i.putExtra(RecorderService.EXTRA_CODE, resultCode)
        i.putExtra(RecorderService.EXTRA_DATA, data)
        startForegroundService(i)
        moveTaskToBack(true) // sai da frente para não aparecer no vídeo
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
