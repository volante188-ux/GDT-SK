package com.gdtsk.recorder

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import kotlin.math.min

/**
 * Bolha flutuante com Pausar/Continuar e Parar.
 * Atenção: o Android não oferece como excluir uma janela de sobreposição da captura de tela.
 * Em muitos aparelhos a bolha aparece no vídeo; por isso ela é opcional e a notificação
 * (que não fica sobre a tela) tem os mesmos controles.
 */
class FloatingBubble(
    private val ctx: Context,
    private val onTogglePause: () -> Unit,
    private val onStop: () -> Unit,
) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private var root: LinearLayout? = null
    private var pauseBtn: IconButton? = null

    private val params = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = 24
        y = 240
    }

    fun show() {
        if (root != null) return
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        fun btn(kind: Int, tint: Int, click: (() -> Unit)?) = IconButton(ctx, kind, tint).apply {
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
            if (click != null) setOnClickListener { click() }
        }

        val handle = btn(IconButton.HANDLE, 0xFFBBBBBB.toInt(), null)
        val pause = btn(IconButton.PAUSE, Color.WHITE) { onTogglePause() }
        val stop = btn(IconButton.STOP, 0xFFFF5252.toInt()) { onStop() }
        pauseBtn = pause

        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply {
                setColor(0xCC1E1E1E.toInt())
                cornerRadius = dp(24).toFloat()
            }
            addView(handle)
            addView(pause)
            addView(stop)
        }

        // Arrastar pela alça
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    runCatching { wm.updateViewLayout(bar, params) }
                }
            }
            true
        }

        try {
            wm.addView(bar, params)
            root = bar
        } catch (e: Exception) {
            root = null // sem permissão de sobreposição: segue só com a notificação
        }
    }

    fun setPaused(paused: Boolean) {
        pauseBtn?.kind = if (paused) IconButton.PLAY else IconButton.PAUSE
    }

    fun hide() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        pauseBtn = null
    }

    private class IconButton(ctx: Context, initialKind: Int, tint: Int) : View(ctx) {
        companion object {
            const val PAUSE = 0
            const val PLAY = 1
            const val STOP = 2
            const val HANDLE = 3
        }

        var kind: Int = initialKind
            set(value) {
                field = value
                invalidate()
            }

        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = tint
            style = Paint.Style.FILL
        }

        override fun onDraw(c: Canvas) {
            val cx = width / 2f
            val cy = height / 2f
            val s = min(width, height) * 0.28f
            when (kind) {
                PAUSE -> {
                    c.drawRect(cx - s * 0.9f, cy - s, cx - s * 0.2f, cy + s, paint)
                    c.drawRect(cx + s * 0.2f, cy - s, cx + s * 0.9f, cy + s, paint)
                }
                PLAY -> {
                    val p = Path()
                    p.moveTo(cx - s * 0.7f, cy - s)
                    p.lineTo(cx + s, cy)
                    p.lineTo(cx - s * 0.7f, cy + s)
                    p.close()
                    c.drawPath(p, paint)
                }
                STOP -> c.drawRect(cx - s * 0.9f, cy - s * 0.9f, cx + s * 0.9f, cy + s * 0.9f, paint)
                else -> for (dy in floatArrayOf(-s, 0f, s)) c.drawCircle(cx, cy + dy, s * 0.22f, paint)
            }
        }
    }
}
