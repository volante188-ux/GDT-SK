package com.gdtsk.recorder

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Surface
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Pipeline de gravação: VirtualDisplay -> MediaCodec (H.264) -> MediaMuxer (MP4)
 *                       AudioRecord (mic ou áudio interno) -> MediaCodec (AAC) -> MediaMuxer
 * Tudo acelerado por hardware, sem cópia de quadros na CPU.
 */
class ScreenRecorder(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val cfg: RecConfig,
    private val onError: (String) -> Unit,
    private val onWarning: (String) -> Unit,
) {
    companion object {
        private const val SAMPLE_RATE = 44100
        private const val TIMEOUT_US = 10_000L
    }

    private class Sample(val video: Boolean, val data: ByteArray, val flags: Int, val ptsUs: Long)

    private var output: Storage.Output? = null
    private var muxer: MediaMuxer? = null
    private var videoCodec: MediaCodec? = null
    private var audioCodec: MediaCodec? = null
    private var audioRecord: AudioRecord? = null
    private var audioChannels = 2
    private var inputSurface: Surface? = null
    private var display: VirtualDisplay? = null
    private var drainThread: Thread? = null
    private var audioThread: Thread? = null

    @Volatile private var audioRunning = false
    @Volatile private var paused = false
    @Volatile private var pauseStartUs = 0L
    @Volatile private var resumeUs = 0L
    @Volatile private var pausedTotalUs = 0L
    @Volatile private var audioDisabled = false

    private var startUs = 0L
    private var stopped = false
    private var resultUri: Uri? = null

    // Estado do muxer (usado só pela thread de drenagem)
    private var videoTrack = -1
    private var audioTrack = -1
    private var expectedTracks = 1
    private var muxerStarted = false
    private var videoBase = Long.MIN_VALUE
    @Volatile private var wroteSamples = false
    private val pending = ArrayList<Sample>()
    private val writeInfo = MediaCodec.BufferInfo()

    // ------------------------------------------------------------------ início

    fun start() {
        try {
            val out = Storage.open(ctx)
            output = out
            muxer = out.muxer

            val name = DeviceLimits.encoderName
            val vc = if (name != null) MediaCodec.createByCodecName(name)
            else MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            val vf = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, cfg.width, cfg.height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, cfg.bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, cfg.fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                setInteger(MediaFormat.KEY_OPERATING_RATE, cfg.fps)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
                // Se a tela ficar parada, repete o último quadro para o vídeo não "travar".
                setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 1_000_000L / min(cfg.fps, 30))
            }
            vc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = vc.createInputSurface()
            vc.start()
            videoCodec = vc

            setupAudio()
            expectedTracks = if (audioCodec != null) 2 else 1

            startUs = System.nanoTime() / 1000
            display = projection.createVirtualDisplay(
                "GDTSK", cfg.width, cfg.height, cfg.dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface, null, null
            ) ?: throw IllegalStateException("Não foi possível iniciar a captura da tela.")

            drainThread = Thread({ drainLoop() }, "gdtsk-drain").also { it.start() }
            if (audioCodec != null) {
                audioRunning = true
                audioThread = Thread({ audioLoop() }, "gdtsk-audio").also { it.start() }
            }
        } catch (e: Exception) {
            releaseAll()
            runCatching { muxer?.release() }
            output?.close(false)
            throw e
        }
    }

    @SuppressLint("MissingPermission")
    private fun setupAudio() {
        if (cfg.audio == Audio.NONE) return
        var rec: AudioRecord? = null
        var codec: MediaCodec? = null
        try {
            val mic = cfg.audio == Audio.MIC
            val channels = if (mic) 1 else 2
            val mask = if (mic) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
            val minBuf = AudioRecord.getMinBufferSize(SAMPLE_RATE, mask, AudioFormat.ENCODING_PCM_16BIT)
            if (minBuf <= 0) throw IllegalStateException("buffer de áudio inválido")
            val size = max(minBuf * 2, 16384)

            rec = if (mic) {
                AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE, mask, AudioFormat.ENCODING_PCM_16BIT, size)
            } else {
                if (Build.VERSION.SDK_INT < 29) throw IllegalStateException("áudio interno exige Android 10+")
                val pc = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                AudioRecord.Builder()
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(SAMPLE_RATE)
                            .setChannelMask(mask)
                            .build()
                    )
                    .setBufferSizeInBytes(size)
                    .setAudioPlaybackCaptureConfig(pc)
                    .build()
            }
            if (rec.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord não inicializou")
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("AudioRecord não gravou")

            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, SAMPLE_RATE, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, if (channels == 2) 128_000 else 96_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            codec.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            codec.start()

            audioRecord = rec
            audioChannels = channels
            audioCodec = codec
        } catch (e: Exception) {
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            runCatching { codec?.release() }
            audioRecord = null
            audioCodec = null
            onWarning("Áudio indisponível neste modo/aparelho. Gravando sem áudio.")
        }
    }

    // ------------------------------------------------------------------ pausa

    fun pause() {
        if (paused || stopped) return
        pauseStartUs = System.nanoTime() / 1000
        paused = true
        videoCodec?.let {
            runCatching { it.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 1) }) }
        }
    }

    fun resume() {
        if (!paused || stopped) return
        val now = System.nanoTime() / 1000
        pausedTotalUs += now - pauseStartUs
        resumeUs = now
        paused = false
        videoCodec?.let {
            runCatching {
                it.setParameters(Bundle().apply {
                    putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 0)
                    putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0)
                })
            }
        }
    }

    private fun inPause(rawUs: Long) = rawUs >= pauseStartUs && (paused || rawUs < resumeUs)

    // ------------------------------------------------------------------ parada

    /** Finaliza o MP4 e o publica na galeria. Bloqueante: chamar fora da thread principal. */
    fun stop(): Uri? {
        synchronized(this) {
            if (stopped) return resultUri
            stopped = true
        }
        runCatching { display?.release() }
        videoCodec?.let {
            runCatching { it.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_SUSPEND, 0) }) }
            runCatching { it.signalEndOfInputStream() }
        }
        audioRunning = false
        runCatching { audioThread?.join(3000) }
        runCatching { drainThread?.join(6000) }

        var ok = false
        val m = muxer
        if (m != null && muxerStarted && wroteSamples) {
            ok = try {
                m.stop()
                true
            } catch (e: Exception) {
                false
            }
        }
        releaseAll()
        runCatching { m?.release() }
        resultUri = output?.close(ok)
        return resultUri
    }

    private fun releaseAll() {
        runCatching { display?.release() }
        runCatching { audioRecord?.stop() }
        runCatching { audioRecord?.release() }
        runCatching { audioCodec?.stop() }
        runCatching { audioCodec?.release() }
        runCatching { videoCodec?.stop() }
        runCatching { videoCodec?.release() }
        runCatching { inputSurface?.release() }
    }

    // ------------------------------------------------------------------ vídeo + muxer

    private fun drainLoop() {
        try {
            val info = MediaCodec.BufferInfo()
            var videoDone = false
            var audioDone = audioCodec == null
            while (!(videoDone && audioDone)) {
                if (!videoDone) videoDone = drain(videoCodec!!, true, info)
                if (!audioDone) audioDone = drain(audioCodec!!, false, info)
            }
        } catch (e: Exception) {
            onError("Erro na gravação: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    /** Esvazia o codificador. Retorna true quando chegou ao fim do fluxo. */
    private fun drain(codec: MediaCodec, video: Boolean, info: MediaCodec.BufferInfo): Boolean {
        while (true) {
            val idx = codec.dequeueOutputBuffer(info, TIMEOUT_US)
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onFormat(codec.outputFormat, video)
                idx >= 0 -> {
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    val buf = codec.getOutputBuffer(idx)
                    if (info.size > 0 && buf != null) handleSample(buf, info, video)
                    codec.releaseOutputBuffer(idx, false)
                    if (eos) return true
                }
            }
        }
    }

    private fun onFormat(fmt: MediaFormat, video: Boolean) {
        val m = muxer ?: return
        if (!video && audioDisabled) return
        if (video) videoTrack = m.addTrack(fmt) else audioTrack = m.addTrack(fmt)
        val added = (if (videoTrack >= 0) 1 else 0) + (if (audioTrack >= 0) 1 else 0)
        if (added == expectedTracks) startMuxer()
    }

    private fun startMuxer() {
        val m = muxer ?: return
        m.start()
        muxerStarted = true
        for (s in pending) {
            write(s.video, ByteBuffer.wrap(s.data), 0, s.data.size, s.flags, s.ptsUs)
        }
        pending.clear()
    }

    private fun handleSample(buf: ByteBuffer, info: MediaCodec.BufferInfo, video: Boolean) {
        if (!video && audioDisabled) return
        var pts = info.presentationTimeUs
        if (video) {
            if (videoBase == Long.MIN_VALUE) {
                videoBase = if (abs(pts - startUs) < 5_000_000L) startUs else pts
            }
            if (inPause(pts)) return
            pts = pts - videoBase - pausedTotalUs
        }
        if (pts < 0) pts = 0
        buf.position(info.offset)
        buf.limit(info.offset + info.size)
        if (!muxerStarted) {
            val arr = ByteArray(info.size)
            buf.get(arr)
            pending.add(Sample(video, arr, info.flags, pts))
            // Se o áudio nunca iniciou, segue só com vídeo em vez de acumular memória.
            if (pending.size > 300 && videoTrack >= 0 && audioTrack < 0) {
                audioDisabled = true
                expectedTracks = 1
                startMuxer()
            }
            return
        }
        write(video, buf, info.offset, info.size, info.flags, pts)
    }

    private fun write(video: Boolean, buf: ByteBuffer, offset: Int, size: Int, flags: Int, pts: Long) {
        val m = muxer ?: return
        val track = if (video) videoTrack else audioTrack
        if (track < 0) return
        buf.position(offset)
        buf.limit(offset + size)
        writeInfo.set(offset, size, pts, flags)
        m.writeSampleData(track, buf, writeInfo)
        wroteSamples = true
    }

    // ------------------------------------------------------------------ áudio

    private fun audioLoop() {
        val rec = audioRecord ?: return
        val codec = audioCodec ?: return
        val bytesPerFrame = 2 * audioChannels
        val chunk = ByteArray(4096)
        var frames = 0L
        var baseUs = -1L
        try {
            while (audioRunning) {
                val n = rec.read(chunk, 0, chunk.size)
                if (n < 0) {
                    onWarning("Captura de áudio interrompida.")
                    break
                }
                if (n == 0) continue
                if (baseUs < 0) {
                    val chunkUs = (n / bytesPerFrame) * 1_000_000L / SAMPLE_RATE
                    baseUs = max(0L, System.nanoTime() / 1000 - startUs - chunkUs)
                }
                if (paused) continue // lê e descarta, para o buffer não estourar
                var off = 0
                while (off < n && audioRunning) {
                    val i = codec.dequeueInputBuffer(TIMEOUT_US)
                    if (i < 0) continue
                    val ib = codec.getInputBuffer(i) ?: continue
                    ib.clear()
                    var len = min(n - off, ib.remaining())
                    len = len / bytesPerFrame * bytesPerFrame
                    if (len <= 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, 0)
                        break
                    }
                    ib.put(chunk, off, len)
                    codec.queueInputBuffer(i, 0, len, baseUs + frames * 1_000_000L / SAMPLE_RATE, 0)
                    frames += len / bytesPerFrame
                    off += len
                }
            }
        } catch (e: Exception) {
            onWarning("Captura de áudio interrompida.")
        }
        sendEos(codec, max(0L, baseUs) + frames * 1_000_000L / SAMPLE_RATE)
    }

    private fun sendEos(codec: MediaCodec, ptsUs: Long) {
        repeat(300) {
            try {
                val i = codec.dequeueInputBuffer(TIMEOUT_US)
                if (i >= 0) {
                    codec.queueInputBuffer(i, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    return
                }
            } catch (e: Exception) {
                return
            }
        }
    }
}
