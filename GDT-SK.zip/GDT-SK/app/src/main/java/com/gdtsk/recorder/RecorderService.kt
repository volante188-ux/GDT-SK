package com.gdtsk.recorder

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.widget.Toast

/** Serviço em primeiro plano que mantém a gravação viva e oferece os controles pela notificação. */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.gdtsk.recorder.START"
        const val ACTION_TOGGLE_PAUSE = "com.gdtsk.recorder.TOGGLE_PAUSE"
        const val ACTION_STOP = "com.gdtsk.recorder.STOP"
        const val EXTRA_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL_ID = "gdtsk_rec"
        private const val NOTIF_ID = 1

        @Volatile
        var active = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var recorder: ScreenRecorder? = null
    private var projection: MediaProjection? = null
    private var projectionCb: MediaProjection.Callback? = null
    private var bubble: FloatingBubble? = null
    private var paused = false
    private var stopping = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording(intent)
            ACTION_TOGGLE_PAUSE -> togglePause()
            ACTION_STOP -> stopRecording()
            else -> if (recorder == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ iniciar

    private fun startRecording(intent: Intent) {
        if (recorder != null) return
        val cfg = RecConfig.from(intent)
        createChannel()

        // O Android exige o serviço em primeiro plano ANTES de obter a MediaProjection.
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                if (Build.VERSION.SDK_INT >= 30 && cfg.audio == Audio.MIC &&
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                ) {
                    type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                }
                startForeground(NOTIF_ID, buildNotification(false), type)
            } else {
                startForeground(NOTIF_ID, buildNotification(false))
            }
        } catch (e: Exception) {
            fail("Não foi possível iniciar o serviço de gravação: ${e.message}")
            return
        }

        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_DATA)
        }
        if (data == null) {
            fail("Permissão de captura inválida.")
            return
        }

        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data)
            val cb = object : MediaProjection.Callback() {
                override fun onStop() {
                    // O usuário (ou o sistema) encerrou a captura: salva o que já foi gravado.
                    main.post { stopRecording() }
                }
            }
            proj.registerCallback(cb, main) // obrigatório no Android 14+ antes do VirtualDisplay
            projection = proj
            projectionCb = cb

            val rec = ScreenRecorder(
                this, proj, cfg,
                onError = { msg -> main.post { toast(msg); stopRecording() } },
                onWarning = { msg -> main.post { toast(msg) } },
            )
            rec.start()
            recorder = rec
            paused = false
            stopping = false
            active = true

            if (cfg.bubble && Settings.canDrawOverlays(this)) {
                bubble = FloatingBubble(this, { togglePause() }, { stopRecording() }).also { it.show() }
            }
        } catch (e: Exception) {
            fail("Não foi possível iniciar a gravação: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------------------------ pausar / continuar

    private fun togglePause() {
        val r = recorder ?: return
        if (stopping) return
        paused = !paused
        if (paused) r.pause() else r.resume()
        bubble?.setPaused(paused)
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(paused))
    }

    // ------------------------------------------------------------------ parar

    private fun stopRecording() {
        if (stopping) return
        val r = recorder
        if (r == null) {
            teardown()
            return
        }
        stopping = true
        recorder = null
        bubble?.hide()
        bubble = null
        Thread({
            val uri = try {
                r.stop()
            } catch (e: Exception) {
                null
            }
            main.post {
                toast(
                    if (uri != null) "Gravação salva em Filmes/GDT SK"
                    else "Não foi possível salvar a gravação (vazia ou interrompida)."
                )
                teardown()
            }
        }, "gdtsk-stop").start()
    }

    private fun teardown() {
        projectionCb?.let { cb -> runCatching { projection?.unregisterCallback(cb) } }
        runCatching { projection?.stop() }
        projection = null
        projectionCb = null
        bubble?.hide()
        bubble = null
        active = false
        stopping = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(msg: String) {
        toast(msg)
        recorder = null
        teardown()
    }

    override fun onDestroy() {
        bubble?.hide()
        bubble = null
        val r = recorder
        recorder = null
        if (r != null) Thread({ runCatching { r.stop() } }, "gdtsk-stop-destroy").start()
        active = false
        super.onDestroy()
    }

    // ------------------------------------------------------------------ notificação

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Gravação de tela", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(paused: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )

        fun action(act: String, label: String, req: Int): Notification.Action {
            val pi = PendingIntent.getService(
                this, req, Intent(this, RecorderService::class.java).setAction(act),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_notif), label, pi).build()
        }

        val b = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("GDT SK")
            .setContentText(if (paused) "Gravação pausada" else "Gravando a tela…")
            .setContentIntent(open)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(action(ACTION_TOGGLE_PAUSE, if (paused) "Continuar" else "Pausar", 1))
            .addAction(action(ACTION_STOP, "Parar", 2))
        if (Build.VERSION.SDK_INT >= 31) {
            b.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return b.build()
    }

    private fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show()
}
